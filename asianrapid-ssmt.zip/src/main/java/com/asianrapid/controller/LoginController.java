package com.asianrapid.controller;

import com.asianrapid.po.SysUser;
import com.asianrapid.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * @Auther: wangminghao
 * @Description:
 * @Date: Created in 下午 16:12 2018/2/9 0009
 */
@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping("/insert")
    public ModelAndView register(SysUser user){
        int i = userService.insertUser(user);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("register");
        if (i == 1){
            modelAndView.addObject("success", true);
        }else{
            modelAndView.addObject("error", true);
        }
        return modelAndView;
    }

    @RequestMapping("/user")
    public String login(SysUser user, Model model){

        model.addAttribute(user);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && !authentication.getPrincipal().equals("anonymousUser")
                && authentication.isAuthenticated()){

            return "user";
        }
        return "login";
    }
}
