package com.asianrapid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Auther: wangminghao
 * @Description:
 * @Date: Created in 上午 9:32 2018/2/9 0009
 */
@SpringBootApplication
public class Application{

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
